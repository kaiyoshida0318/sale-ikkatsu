const CACHE_NAME = 'sale-ikkatsu-v0.7.0';
const VENDOR_CACHE = 'sale-ikkatsu-vendor-v1';

const APP_FILES = [
  './',
  './index.html',
  './app/merger.js',
  './app/builder.js',
  './assets/mark-192.png',
  './assets/favicon-32.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names
          .filter((n) => n !== CACHE_NAME && n !== VENDOR_CACHE)
          .map((n) => caches.delete(n))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  if (url.hostname === 'cdnjs.cloudflare.com') {
    event.respondWith(cacheFirst(event.request, VENDOR_CACHE));
    return;
  }

  if (url.origin === location.origin) {
    if (url.pathname.includes('/app/') ||
        url.pathname.includes('/assets/') ||
        url.pathname.endsWith('.html') ||
        url.pathname.endsWith('/')) {
      event.respondWith(networkFirst(event.request, CACHE_NAME));
      return;
    }
  }
});

async function cacheFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  if (cached) return cached;
  const response = await fetch(request);
  if (response.ok) cache.put(request, response.clone());
  return response;
}

async function networkFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  try {
    const response = await fetch(request);
    if (response.ok) cache.put(request, response.clone());
    return response;
  } catch (e) {
    const cached = await cache.match(request);
    if (cached) return cached;
    throw e;
  }
}
